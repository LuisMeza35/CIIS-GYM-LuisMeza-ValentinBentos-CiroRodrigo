function enableDarkMode(){
    let main_body = document.body;
    main_body.classList.toggle("dark-mode");
}